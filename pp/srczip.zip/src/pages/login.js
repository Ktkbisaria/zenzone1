import React from 'react';
import './login.css';
import img from '../assests/WhatsApp Image 2024-03-04 at 11.14.21_67e52370.jpg';

function LoginPage(){
    return(
        <div className="smallbox">
            <img className="sideimg" src={img}></img>
            <p className="cName2">ZENZONE</p>
            <h1 className="sign">SIGN</h1>
            <h1 className="up">UP</h1>
            <input type="email" className="uEmail1" placeholder="Email"></input>
            <input type="password" className="uPassword1" placeholder="Password"></input>
            <button type="submit" className="signupbtn">LOGIN</button>
            <button className="loginbtn">SIGNUP</button>

            
        </div>
    )
}

export default LoginPage;