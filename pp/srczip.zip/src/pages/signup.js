import React from "react";
import { Link } from "react-router-dom";
import { useState } from "react";
import './signup.css';
import img from '../assests/WhatsApp Image 2024-03-04 at 11.14.21_67e52370.jpg'
import axios from 'axios';

function SignupPage(){
    const [name, setName]= useState()
    const [username, setUsername]= useState()
    const [email, setEmail]= useState()
    const [password, setPassword]= useState()

    // const handleSubmit= (e) => {
    //     e.preventDefault()
    //     axios.post('https://localhost:3001/register', {name, username, email, password})
    //     .then(result => console.log(result))
    //     .catch(err => console.log(err))
    // }

    return(
        <div className="smallbox">
            <img className="sideimg" src={img}></img>
            <p className="cName2">ZENZONE</p>
            <h1 className="sign">SIGN</h1>
            <h1 className="up">UP</h1>
            <form>
            <input 
                type="text" 
                className="flName" 
                placeholder="Name"
                onChange={(e) => setName(e.target.value)}>
            </input>
            <input 
                type="text" c
                lassName="uName" 
                placeholder="Username"
                onChange={(e) => setUsername(e.target.value)}>
            </input>
            <input 
                type="email" 
                className="uEmail" 
                placeholder="Email"
                autoComplete="off"
                onChange={(e) => setEmail(e.target.value)}>
                    
            </input>
            <input 
                type="password" 
                className="uPassword" 
                placeholder="Password"
                autoComplete="off"
                onChange={(e) => setPassword(e.target.value)}>
            </input>
            <button type="submit" className="signupbtn">SIGNUP</button>
            </form>
            <button className="loginbtn">LOGIN</button>

            
        </div>
    )
}

export default SignupPage;