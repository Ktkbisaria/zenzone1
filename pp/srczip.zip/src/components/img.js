import React from "react";
import './img.css';
import img1 from "./img1.png";

function Imgg(){
    return <div className="trying">
    <img src={img1} className="img" alt="lady"/>
    </div>
}
export default Imgg;